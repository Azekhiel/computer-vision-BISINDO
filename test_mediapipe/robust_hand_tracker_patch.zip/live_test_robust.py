#!/usr/bin/env python3
"""
live_test_robust.py
===================
Live webcam test using the robust pose+hand tracker.

Recommended on Jetson Orin Nano:
    python3 live_test_robust.py --cam 0 --fps 30 --feature-mode compat
    python3 live_test_robust.py --cam 0 --csi --fps 30 --pose-every 3

Keys:
    Q/ESC = quit, G = save gif, S = save current feature vector, R = reset gif buffer
"""

from __future__ import annotations

import argparse
import collections
import os
import sys
import threading
import time
from pathlib import Path
from typing import Optional, Tuple

import cv2
import imageio
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
from feature_extractor_robust import make_tracker, extract_features, draw_landmarks, draw_hud


class LatestFrameCamera:
    """Camera reader that always serves the newest frame.

    This prevents live test lag from accumulating when inference is slower than camera FPS.
    """

    def __init__(self, src: int = 0, use_csi: bool = False, width: int = 640, height: int = 480, fps: int = 30):
        self.width, self.height, self.fps = width, height, fps
        self.cap = self._open(src, use_csi, width, height, fps)
        if not self.cap.isOpened():
            raise RuntimeError(f"Cannot open camera src={src} csi={use_csi}")

        self.lock = threading.Lock()
        self.frame: Optional[np.ndarray] = None
        self.ret = False
        self.running = True
        self.thread = threading.Thread(target=self._reader, daemon=True)
        self.thread.start()

        # Wait briefly for first frame.
        t0 = time.perf_counter()
        while self.frame is None and time.perf_counter() - t0 < 2.0:
            time.sleep(0.01)

    def _open(self, src: int, use_csi: bool, width: int, height: int, fps: int):
        if use_csi:
            gst = (
                f"nvarguscamerasrc sensor-id={src} ! "
                f"video/x-raw(memory:NVMM), width={width}, height={height}, format=NV12, framerate={fps}/1 ! "
                f"nvvidconv ! video/x-raw, format=BGRx ! videoconvert ! "
                f"video/x-raw, format=BGR ! appsink max-buffers=1 drop=true sync=false"
            )
            cap = cv2.VideoCapture(gst, cv2.CAP_GSTREAMER)
        else:
            gst = (
                f"v4l2src device=/dev/video{src} ! "
                f"video/x-raw, width={width}, height={height}, framerate={fps}/1 ! "
                f"videoconvert ! video/x-raw, format=BGR ! appsink max-buffers=1 drop=true sync=false"
            )
            cap = cv2.VideoCapture(gst, cv2.CAP_GSTREAMER)
            if not cap.isOpened():
                print("[WARN] GStreamer V4L2 failed, fallback to cv2.CAP_V4L2")
                cap = cv2.VideoCapture(src, cv2.CAP_V4L2)
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
                cap.set(cv2.CAP_PROP_FPS, fps)
                cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        return cap

    def _reader(self) -> None:
        while self.running:
            ret, frame = self.cap.read()
            if ret and frame is not None:
                with self.lock:
                    self.ret = True
                    self.frame = frame
            else:
                time.sleep(0.004)

    def read(self) -> Tuple[bool, Optional[np.ndarray]]:
        with self.lock:
            if not self.ret or self.frame is None:
                return False, None
            return True, self.frame.copy()

    def release(self) -> None:
        self.running = False
        if self.thread.is_alive():
            self.thread.join(timeout=1.0)
        self.cap.release()


def frames_to_gif(frames, path: str, fps: int = 15, max_width: int = 360) -> None:
    if not frames:
        print("[GIF] Buffer kosong.")
        return
    out = []
    for bgr in frames:
        h, w = bgr.shape[:2]
        if w > max_width:
            scale = max_width / w
            bgr = cv2.resize(bgr, (max_width, int(h * scale)), interpolation=cv2.INTER_AREA)
        out.append(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB))
    imageio.mimsave(path, out, duration=1.0 / fps, loop=0)
    print(f"[GIF] Saved {len(out)} frames -> {path}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Robust live hand/pose test")
    parser.add_argument("--cam", type=int, default=0)
    parser.add_argument("--csi", action="store_true")
    parser.add_argument("--width", type=int, default=640)
    parser.add_argument("--height", type=int, default=480)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--model-complexity", type=int, default=0, choices=[0, 1])
    parser.add_argument("--det-conf", type=float, default=0.55)
    parser.add_argument("--track-conf", type=float, default=0.55)
    parser.add_argument("--pose-every", type=int, default=2, help="Run pose every N frames. Higher = faster, less stable anchors.")
    parser.add_argument("--hold-frames", type=int, default=8, help="Keep last hand landmarks for this many missed frames.")
    parser.add_argument("--feature-mode", choices=["compat", "stable"], default="compat")
    parser.add_argument("--no-mirror-handedness", action="store_true", help="Use if L/R labels look inverted on your camera.")
    parser.add_argument("--gif-sec", type=float, default=5.0)
    parser.add_argument("--gif-out", type=str, default="live_test_robust.gif")
    parser.add_argument("--no-display", action="store_true")
    args = parser.parse_args()

    ring = collections.deque(maxlen=max(1, int(args.gif_sec * args.fps)))
    cam = LatestFrameCamera(args.cam, args.csi, args.width, args.height, args.fps)
    tracker = make_tracker(
        model_complexity=args.model_complexity,
        det_conf=args.det_conf,
        track_conf=args.track_conf,
        pose_every=args.pose_every,
        hold_frames=args.hold_frames,
        mirror_handedness=not args.no_mirror_handedness,
    )

    print("=" * 64)
    print("Robust live test opened")
    print(f"camera={args.cam} csi={args.csi} size={args.width}x{args.height} fps={args.fps}")
    print(f"feature_mode={args.feature_mode} pose_every={args.pose_every} hold_frames={args.hold_frames}")
    print("Keys: Q/ESC quit | G save GIF | S save feature .npy | R reset buffer")
    print("=" * 64)

    fps_counter = 0
    fps_t0 = time.perf_counter()
    display_fps = 0.0
    last_feat = None

    try:
        while True:
            ret, frame = cam.read()
            if not ret or frame is None:
                time.sleep(0.002)
                continue

            if frame.shape[1] != args.width or frame.shape[0] != args.height:
                frame = cv2.resize(frame, (args.width, args.height), interpolation=cv2.INTER_AREA)

            result = tracker.process(frame)
            last_feat = extract_features(result, mode=args.feature_mode)

            vis = draw_landmarks(frame.copy(), result)
            vis = draw_hud(vis, result, display_fps, feature_mode=args.feature_mode)
            ring.append(vis.copy())

            if not args.no_display:
                cv2.imshow("Robust Hand Live", vis)

            fps_counter += 1
            now = time.perf_counter()
            if now - fps_t0 >= 0.5:
                display_fps = fps_counter / (now - fps_t0)
                fps_counter = 0
                fps_t0 = now

            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), ord("Q"), 27):
                break
            if key in (ord("g"), ord("G")):
                frames_to_gif(list(ring), args.gif_out, fps=15)
            if key in (ord("s"), ord("S")) and last_feat is not None:
                out = f"live_feat_{args.feature_mode}.npy"
                np.save(out, last_feat.astype(np.float32))
                print(f"[SNAP] Saved {last_feat.shape} -> {out}")
            if key in (ord("r"), ord("R")):
                ring.clear()
                print("[RING] reset")
    except KeyboardInterrupt:
        print("\n[INFO] stopped")
    finally:
        cam.release()
        tracker.close()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
