"""
feature_extractor_robust.py
===========================
Robust live-friendly pose + two-hand tracker for Jetson / CPU.

Design goal:
- More stable than raw MediaPipe Holistic for live hand testing.
- Keeps physical left/right hand identity stable during crossing / self-handshake.
- Avoids hard-zero feature jumps when a hand is briefly occluded.
- Keeps a compatibility 179-dim feature vector for old training pipelines.

Dependencies:
    pip install mediapipe opencv-python numpy
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
import time

import cv2
import numpy as np
import mediapipe as mp

mp_pose = mp.solutions.pose
mp_hands = mp.solutions.hands

# Old feature layout compatibility: 6 pose points, 2 hands, 16 angles per hand, 3 flags.
POSE_KP_IDX = [11, 12, 13, 14, 23, 24]  # L/R shoulder, elbow, hip
POSE_WRIST_IDX = {"left": 15, "right": 16}

HAND_ANGLE_TRIPLETS = [
    (5, 0, 1), (0, 1, 2), (1, 2, 3), (2, 3, 4),          # thumb
    (0, 5, 6), (5, 6, 7), (6, 7, 8),                     # index
    (0, 9, 10), (9, 10, 11), (10, 11, 12),               # middle
    (0, 13, 14), (13, 14, 15), (14, 15, 16),             # ring
    (0, 17, 18), (17, 18, 19), (18, 19, 20),             # pinky
]

HAND_CONNECTIONS = tuple(mp_hands.HAND_CONNECTIONS)


def _safe_norm(x: np.ndarray, eps: float = 1e-6) -> float:
    return float(max(np.linalg.norm(x), eps))


def _angle_at_b(pa: np.ndarray, pb: np.ndarray, pc: np.ndarray) -> float:
    ba, bc = pa - pb, pc - pb
    denom = _safe_norm(ba) * _safe_norm(bc)
    cos_val = float(np.dot(ba, bc) / denom)
    return float(np.arccos(np.clip(cos_val, -1.0, 1.0)))


def _hand_angles(lm: np.ndarray) -> np.ndarray:
    angles = np.zeros(16, dtype=np.float32)
    for j, (a, b, c) in enumerate(HAND_ANGLE_TRIPLETS):
        angles[j] = _angle_at_b(lm[a], lm[b], lm[c])
    return angles


def _hand_scale(lm: np.ndarray) -> float:
    # Stable local hand scale: wrist -> middle MCP and index MCP -> pinky MCP.
    return max(_safe_norm(lm[0] - lm[9]), _safe_norm(lm[5] - lm[17]), 1e-4)


def _relative_hand(lm: np.ndarray) -> np.ndarray:
    return ((lm - lm[0]) / _hand_scale(lm)).astype(np.float32)


def _np_landmarks(lm_list) -> np.ndarray:
    arr = np.zeros((21, 3), dtype=np.float32)
    for i, p in enumerate(lm_list.landmark):
        arr[i] = (p.x, p.y, p.z)
    return arr


def _clip01(v: float) -> float:
    return float(np.clip(v, 0.0, 1.0))


@dataclass
class HandDetection:
    landmarks: np.ndarray
    score: float = 1.0
    mp_label: str = ""

    @property
    def wrist(self) -> np.ndarray:
        return self.landmarks[0]

    @property
    def center(self) -> np.ndarray:
        return np.mean(self.landmarks[[0, 5, 9, 13, 17]], axis=0)


@dataclass
class HandState:
    name: str
    hold_frames: int = 8
    landmarks: np.ndarray = field(default_factory=lambda: np.zeros((21, 3), dtype=np.float32))
    detected: bool = False         # true only for current frame detection
    valid: bool = False            # true for detected OR short held state
    age: int = 10_000              # frames since last detection
    quality: float = 0.0           # decays during occlusion
    last_update_t: float = 0.0

    def update(self, det: HandDetection, alpha_slow: float = 0.38, alpha_fast: float = 0.72) -> None:
        new_lm = det.landmarks.astype(np.float32)
        if not self.valid or self.age > self.hold_frames:
            self.landmarks = new_lm
        else:
            # Fast correction for real motion, slow correction for tiny jitter.
            wrist_jump = _safe_norm(new_lm[0, :2] - self.landmarks[0, :2])
            alpha = alpha_fast if wrist_jump > 0.055 else alpha_slow
            self.landmarks = (1.0 - alpha) * self.landmarks + alpha * new_lm
        self.detected = True
        self.valid = True
        self.age = 0
        self.quality = _clip01(0.15 + 0.85 * det.score)
        self.last_update_t = time.perf_counter()

    def miss(self) -> None:
        self.detected = False
        self.age += 1
        if self.age <= self.hold_frames:
            # Do not hard-zero. Keep last pose briefly but lower confidence.
            self.valid = True
            self.quality = _clip01(self.quality * 0.72)
        else:
            self.valid = False
            self.quality = 0.0


@dataclass
class RobustFrameResult:
    pose_landmarks: Optional[object]
    pose_selected: np.ndarray
    pose_ok: float
    hands: Dict[str, HandState]
    raw_detections: List[HandDetection]
    self_handshake_score: float
    infer_ms: float

    @property
    def left_hand(self) -> HandState:
        return self.hands["left"]

    @property
    def right_hand(self) -> HandState:
        return self.hands["right"]


class RobustHolisticTracker:
    """Pose + Hands with temporal identity assignment.

    MediaPipe Holistic often gives clean landmarks, but its left_hand/right_hand output can
    jitter or disappear in heavy occlusion. This class uses MediaPipe Pose for body anchors,
    MediaPipe Hands for two-hand detection, then assigns detections to stable physical slots.
    """

    def __init__(
        self,
        model_complexity: int = 0,
        det_conf: float = 0.55,
        track_conf: float = 0.55,
        pose_every: int = 2,
        hold_frames: int = 8,
        mirror_handedness: bool = True,
        max_num_hands: int = 2,
    ) -> None:
        self.pose_every = max(1, int(pose_every))
        self.frame_i = 0
        self.pose_result = None
        self.mirror_handedness = bool(mirror_handedness)
        self.pose = mp_pose.Pose(
            static_image_mode=False,
            model_complexity=int(model_complexity),
            smooth_landmarks=True,
            enable_segmentation=False,
            min_detection_confidence=float(det_conf),
            min_tracking_confidence=float(track_conf),
        )
        self.hands_detector = mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=int(max_num_hands),
            model_complexity=int(model_complexity),
            min_detection_confidence=float(det_conf),
            min_tracking_confidence=float(track_conf),
        )
        self.hands = {
            "left": HandState("left", hold_frames=hold_frames),
            "right": HandState("right", hold_frames=hold_frames),
        }

    def close(self) -> None:
        self.pose.close()
        self.hands_detector.close()

    def _pose_selected_and_anchors(self) -> Tuple[np.ndarray, float, Dict[str, np.ndarray]]:
        selected = np.zeros((6, 3), dtype=np.float32)
        anchors: Dict[str, np.ndarray] = {}
        pose_ok = 0.0
        if not self.pose_result or not self.pose_result.pose_landmarks:
            return selected, pose_ok, anchors

        lm = self.pose_result.pose_landmarks.landmark
        vis = []
        for i, idx in enumerate(POSE_KP_IDX):
            selected[i] = (lm[idx].x, lm[idx].y, lm[idx].z)
            vis.append(getattr(lm[idx], "visibility", 0.0))
        pose_ok = 1.0 if np.mean(vis) > 0.35 else 0.0

        for name, idx in POSE_WRIST_IDX.items():
            p = lm[idx]
            if getattr(p, "visibility", 0.0) > 0.25:
                anchors[name] = np.array([p.x, p.y, p.z], dtype=np.float32)
        return selected, pose_ok, anchors

    def _detect_hands(self, rgb: np.ndarray) -> List[HandDetection]:
        raw = self.hands_detector.process(rgb)
        detections: List[HandDetection] = []
        if not raw.multi_hand_landmarks:
            return detections

        handed = raw.multi_handedness or []
        for i, lm_list in enumerate(raw.multi_hand_landmarks):
            label, score = "", 1.0
            if i < len(handed) and handed[i].classification:
                cls = handed[i].classification[0]
                label = cls.label or ""
                score = float(cls.score or 0.0)
            detections.append(HandDetection(_np_landmarks(lm_list), score=score, mp_label=label))
        # Keep the two highest confidence detections if MediaPipe emits extra candidates.
        detections.sort(key=lambda d: d.score, reverse=True)
        return detections[:2]

    def _handedness_cost(self, det: HandDetection, physical_label: str) -> float:
        # MediaPipe Hands handedness is useful but not always reliable with mirrored webcam feeds.
        if not det.mp_label:
            return 0.0
        expected = "Left" if physical_label == "left" else "Right"
        if self.mirror_handedness:
            expected = "Right" if physical_label == "left" else "Left"
        return 0.0 if det.mp_label == expected else 0.20

    def _assignment_cost(self, det: HandDetection, physical_label: str, pose_anchors: Dict[str, np.ndarray]) -> float:
        cost = 0.0
        st = self.hands[physical_label]
        if st.valid:
            # Temporal continuity is the strongest prior.
            cost += 2.0 * _safe_norm(det.wrist[:2] - st.landmarks[0, :2])
            # Shape continuity after wrist alignment helps during hand crossing.
            prev_rel = _relative_hand(st.landmarks)
            new_rel = _relative_hand(det.landmarks)
            cost += 0.18 * float(np.mean(np.linalg.norm(prev_rel[:, :2] - new_rel[:, :2], axis=1)))
        else:
            cost += 0.18

        if physical_label in pose_anchors:
            # Pose wrist anchors keep physical left/right identity stable in self-handshake.
            cost += 1.55 * _safe_norm(det.wrist[:2] - pose_anchors[physical_label][:2])

        cost += self._handedness_cost(det, physical_label)
        return float(cost)

    def _assign(self, detections: List[HandDetection], pose_anchors: Dict[str, np.ndarray]) -> Dict[str, HandDetection]:
        if not detections:
            return {}

        labels = ["left", "right"]
        if len(detections) == 1:
            d = detections[0]
            costs = {lab: self._assignment_cost(d, lab, pose_anchors) for lab in labels}
            return {min(costs, key=costs.get): d}

        d0, d1 = detections[:2]
        cost_lr = self._assignment_cost(d0, "left", pose_anchors) + self._assignment_cost(d1, "right", pose_anchors)
        cost_rl = self._assignment_cost(d0, "right", pose_anchors) + self._assignment_cost(d1, "left", pose_anchors)
        if cost_lr <= cost_rl:
            return {"left": d0, "right": d1}
        return {"left": d1, "right": d0}

    def _self_handshake_score(self) -> float:
        lh, rh = self.hands["left"], self.hands["right"]
        if not (lh.valid and rh.valid):
            return 0.0
        # Close wrists/palms + both hands visible/held = likely hand overlap/self-handshake.
        wrist_d = _safe_norm(lh.landmarks[0, :2] - rh.landmarks[0, :2])
        palm_d = _safe_norm(lh.landmarks[9, :2] - rh.landmarks[9, :2])
        close = np.exp(-18.0 * min(wrist_d, palm_d))
        return float(np.clip(close * min(lh.quality, rh.quality), 0.0, 1.0))

    def process(self, frame_bgr: np.ndarray) -> RobustFrameResult:
        t0 = time.perf_counter()
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        rgb.flags.writeable = False

        # Pose is the heavier part. Run it every N frames, reuse last anchors in between.
        if self.frame_i % self.pose_every == 0 or self.pose_result is None:
            self.pose_result = self.pose.process(rgb)
        detections = self._detect_hands(rgb)

        rgb.flags.writeable = True
        pose_selected, pose_ok, pose_anchors = self._pose_selected_and_anchors()
        assigned = self._assign(detections, pose_anchors)

        for name, st in self.hands.items():
            if name in assigned:
                st.update(assigned[name])
            else:
                st.miss()

        self.frame_i += 1
        infer_ms = (time.perf_counter() - t0) * 1000.0
        return RobustFrameResult(
            pose_landmarks=self.pose_result.pose_landmarks if self.pose_result else None,
            pose_selected=pose_selected,
            pose_ok=pose_ok,
            hands=self.hands,
            raw_detections=detections,
            self_handshake_score=self._self_handshake_score(),
            infer_ms=infer_ms,
        )


def make_tracker(
    model_complexity: int = 0,
    det_conf: float = 0.55,
    track_conf: float = 0.55,
    pose_every: int = 2,
    hold_frames: int = 8,
    mirror_handedness: bool = True,
) -> RobustHolisticTracker:
    return RobustHolisticTracker(
        model_complexity=model_complexity,
        det_conf=det_conf,
        track_conf=track_conf,
        pose_every=pose_every,
        hold_frames=hold_frames,
        mirror_handedness=mirror_handedness,
    )


def extract_features(result: RobustFrameResult, mode: str = "compat") -> np.ndarray:
    """Return feature vector.

    mode="compat" -> 179 dims, same layout as old feature_extractor.py:
        pose 18 + left hand 63 + right hand 63 + left angles 16 + right angles 16 + flags 3.
        Difference: hand coords are smoothed/held briefly during occlusion, and flags are quality scores.

    mode="stable" -> 337 dims, recommended for retraining:
        compat 179 + left relative hand 63 + right relative hand 63 + geometry 16 + quality/meta 16.
    """
    mode = mode.lower().strip()
    feat = np.zeros(179, dtype=np.float32)

    feat[0:18] = result.pose_selected.reshape(-1)

    for label, start, angle_start, flag_idx in (
        ("left", 18, 144, 177),
        ("right", 81, 160, 178),
    ):
        st = result.hands[label]
        if st.valid:
            feat[start:start + 63] = st.landmarks.reshape(-1)
            feat[angle_start:angle_start + 16] = _hand_angles(st.landmarks)
            feat[flag_idx] = st.quality
        else:
            feat[flag_idx] = 0.0

    feat[176] = result.pose_ok

    if mode == "compat":
        return feat

    if mode != "stable":
        raise ValueError("mode must be 'compat' or 'stable'")

    # Richer retraining vector. Relative hand features are less sensitive to camera/person scale.
    left_rel = np.zeros((21, 3), dtype=np.float32)
    right_rel = np.zeros((21, 3), dtype=np.float32)
    lh, rh = result.left_hand, result.right_hand
    if lh.valid:
        left_rel = _relative_hand(lh.landmarks)
    if rh.valid:
        right_rel = _relative_hand(rh.landmarks)

    geom = np.zeros(16, dtype=np.float32)
    if lh.valid and rh.valid:
        geom[0] = _safe_norm(lh.landmarks[0, :2] - rh.landmarks[0, :2])       # wrist distance
        geom[1] = _safe_norm(lh.landmarks[9, :2] - rh.landmarks[9, :2])       # palm distance
        geom[2] = _safe_norm(lh.landmarks[8, :2] - rh.landmarks[8, :2])       # index tip distance
        geom[3] = _safe_norm(lh.landmarks[4, :2] - rh.landmarks[4, :2])       # thumb tip distance
        geom[4] = float(np.dot(left_rel[9, :2], right_rel[9, :2]))
        geom[5] = result.self_handshake_score
        geom[6] = lh.quality
        geom[7] = rh.quality
        geom[8] = float(lh.detected)
        geom[9] = float(rh.detected)
        geom[10] = min(lh.age, 99) / 99.0
        geom[11] = min(rh.age, 99) / 99.0
        geom[12] = _hand_scale(lh.landmarks)
        geom[13] = _hand_scale(rh.landmarks)

    meta = np.zeros(16, dtype=np.float32)
    meta[0] = result.pose_ok
    meta[1] = lh.quality
    meta[2] = rh.quality
    meta[3] = float(lh.detected)
    meta[4] = float(rh.detected)
    meta[5] = result.self_handshake_score
    meta[6] = min(result.infer_ms, 1000.0) / 1000.0

    return np.concatenate([feat, left_rel.reshape(-1), right_rel.reshape(-1), geom, meta]).astype(np.float32)


def _pt(lm: np.ndarray, w: int, h: int) -> Tuple[int, int]:
    return int(np.clip(lm[0] * w, 0, w - 1)), int(np.clip(lm[1] * h, 0, h - 1))


def draw_landmarks(frame: np.ndarray, result: RobustFrameResult) -> np.ndarray:
    h, w = frame.shape[:2]

    # Draw pose using MediaPipe utility when available.
    if result.pose_landmarks:
        mp.solutions.drawing_utils.draw_landmarks(
            frame,
            result.pose_landmarks,
            mp_pose.POSE_CONNECTIONS,
            landmark_drawing_spec=mp.solutions.drawing_styles.get_default_pose_landmarks_style(),
        )

    for label, color in (("left", (70, 220, 255)), ("right", (255, 170, 70))):
        st = result.hands[label]
        if not st.valid:
            continue
        # Dim held/occluded landmarks so you can see when it is extrapolated/held.
        q = st.quality
        draw_color = tuple(int(c * (0.35 + 0.65 * q)) for c in color)
        pts = [_pt(p, w, h) for p in st.landmarks]
        for a, b in HAND_CONNECTIONS:
            cv2.line(frame, pts[a], pts[b], draw_color, 2 if st.detected else 1, cv2.LINE_AA)
        for i, p in enumerate(pts):
            radius = 3 if i in (0, 4, 8, 12, 16, 20) else 2
            cv2.circle(frame, p, radius, draw_color, -1, cv2.LINE_AA)
        wrist = pts[0]
        tag = "L" if label == "left" else "R"
        suffix = "" if st.detected else " hold"
        cv2.putText(frame, f"{tag} {q:.2f}{suffix}", (wrist[0] + 6, wrist[1] - 6),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.42, draw_color, 1, cv2.LINE_AA)

    return frame


def draw_hud(frame: np.ndarray, result: RobustFrameResult, fps: float, feature_mode: str = "compat") -> np.ndarray:
    h, w = frame.shape[:2]
    lh, rh = result.left_hand, result.right_hand

    overlay = frame.copy()
    cv2.rectangle(overlay, (4, 4), (285, 128), (18, 18, 18), -1)
    cv2.addWeighted(overlay, 0.62, frame, 0.38, 0, frame)

    def col(q: float) -> Tuple[int, int, int]:
        if q >= 0.65:
            return (70, 230, 90)
        if q >= 0.25:
            return (80, 190, 255)
        return (60, 80, 230)

    font = cv2.FONT_HERSHEY_SIMPLEX
    cv2.putText(frame, f"FPS {fps:5.1f} | infer {result.infer_ms:5.1f} ms | {feature_mode}",
                (10, 23), font, 0.5, (220, 220, 220), 1, cv2.LINE_AA)
    cv2.putText(frame, f"Pose : {'OK' if result.pose_ok else '--'}", (10, 48), font, 0.48,
                col(result.pose_ok), 1, cv2.LINE_AA)
    cv2.putText(frame, f"Left : q={lh.quality:.2f} {'det' if lh.detected else 'hold' if lh.valid else '--'}",
                (10, 72), font, 0.48, col(lh.quality), 1, cv2.LINE_AA)
    cv2.putText(frame, f"Right: q={rh.quality:.2f} {'det' if rh.detected else 'hold' if rh.valid else '--'}",
                (10, 96), font, 0.48, col(rh.quality), 1, cv2.LINE_AA)
    cv2.putText(frame, f"Self-handshake/overlap: {result.self_handshake_score:.2f}",
                (10, 120), font, 0.44, col(result.self_handshake_score), 1, cv2.LINE_AA)

    # Small confidence bars.
    x0, y0 = 210, 68
    for i, (name, q) in enumerate((("L", lh.quality), ("R", rh.quality))):
        y = y0 + i * 22
        cv2.putText(frame, name, (x0, y + 8), font, 0.38, (190, 190, 190), 1, cv2.LINE_AA)
        cv2.rectangle(frame, (x0 + 18, y), (x0 + 78, y + 10), (55, 55, 55), 1)
        cv2.rectangle(frame, (x0 + 19, y + 1), (x0 + 19 + int(58 * q), y + 9), col(q), -1)

    cv2.putText(frame, "Q/ESC quit | G gif | S npy | R reset", (6, h - 6),
                font, 0.38, (145, 145, 145), 1, cv2.LINE_AA)
    return frame
